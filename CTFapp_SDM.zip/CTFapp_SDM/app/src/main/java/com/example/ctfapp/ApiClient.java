package com.example.ctfapp;

public class ApiClient {
    private static final String API_KEY = "FLAG{api_key_value}";

    public String getApiKey() {
        return API_KEY;
    }
}
